//
//  main.m
//  RACollectionViewReorderableTripletLayout-Demo
//
//  Created by Ryo Aoyama on 5/31/14.
//  Copyright (c) 2014 Ryo Aoyama. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RAAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RAAppDelegate class]));
    }
}
